import java.net.*;
import java.io.*;
public class server {
	private SocketManager socketMan=new SocketManager();
	private int score;	
	private int map[][]=new int [20][20];
	private int lock=-1;//-1���������δ��ʼ
	private int win=0,value=0;
	private int x=-1,y=-1;
	private int for_ini=0;
	void getServer(){
		try{
			ServerSocket serverSocket=new ServerSocket(5421);
			System.out.println("�������׽����Ѵ���");
			if(for_ini==0){//�������˳�ʼ������
				for_ini=1;
				startgame();
			}
			while(true){
				Socket socket=serverSocket.accept();
				new writer_Thread(socket).start();
				socketMan.add(socket);
				socketMan.sendClientInfo();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	private Boolean winner(int x,int y){
		   score=1;
		   //�ж�x++�����Ƿ��Ѿ���������
		   //System.out.println("x:"+x+"y:"+y);
		   for(int i=x;i<x+4&&i<19;){
			   //System.out.println("�ѽ����б�ʽ");
			   if(map[i][y]==map[++i][y]){
				   System.out.println(map[x][y]);
				   score++;
			   }
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�x--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int i=x;i>x-4&&i>0;){
			   if(map[i][y]==map[--i][y]){
				   score++;
				   System.out.println(score);
			   }
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�y++�����Ƿ��Ѿ���������
		   score=1;
		   for(int j=y;j<y+4&&j<19;){
			   if(map[x][j]==map[x][++j])
				   score++;
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�y--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int j=y;j>y-4&&j>0;){
			   if(map[x][j]==map[x][--j])
				   score++;
			   else
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�x++&&y++�����Ƿ��Ѿ���������
		   score=1;
		   for(int i=x,j=y;i<x+4&&i<19&&j>0;){
			   if(map[i][j]==map[++i][--j])
				   score++;
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		 //�ж�x--&&y--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int i=x,j=y;i>x-4&&i>0&&j<19;){
			   //System.out.println("x++&&y++�����б�ing...");
			   if(map[i][j]==map[--i][++j])
				   score++;
			   else
				   break;
			   System.out.println("x++&&y++�����б�ing..."+score);
			   if(score>=5)
				   return true;
		   }
		 //�ж�x--&&y++�����Ƿ��Ѿ���������
		   score=1;
		   for(int i=x,j=y;i>x-4&&i>0&&j>0;){
			   if(map[i][j]==map[--i][--j])
				   score++;
			   else
				   break;
			   //System.out.println(score);
			   if(score>=5)
				   return true;
		   }
		 
		   //�ж�x++&&y--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int i=x,j=y;i<x+4&&i<19&&j<19;){
			   if(map[i][j]==map[++i][++j])
				   score++;
			   else
				   break;
			   System.out.println(score);
			   if(score>=5)
				   return true;
		   }
		   return false;
		   }
	public void startgame(){
		for(int i=0;i<20;i++){
			for(int j=0;j<20;j++){
				map[i][j]=0;
			}
		}
	}
	private void play(){
		if(x>=0&&x<=19&&y>=0&&y<=19&&map[x][y]==0){
	    	   if(lock==0){
	    		   map[x][y]=1;
	    		   value=1;
	    		   //System.out.println("x:"+x+"y:"+y);
	    		   lock=1;
	    		   if(winner(x,y)){
	    			   win=1;	    		 
 			   }
	    		   //System.out.println("�������ߡ�"+flag);
	    	   }
	    	   else if(lock==1){
	    		   map[x][y]=2;
	    		   value=2;
	    		   lock=0;
	    		   if(winner(x,y)){
	    			   win=2;	    			   
	    		   }
	    	   }
	}
	}
	class writer_Thread extends Thread{
	Socket socket=null;
	private BufferedReader reader;
	private PrintWriter writer;
	public writer_Thread(Socket socket){
		this.socket=socket;
	}
	public void run(){
		try{
			reader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
			writer=new PrintWriter(socket.getOutputStream(),true);
			String msg;
			while((msg=reader.readLine())!=null){
				//System.out.println(msg);
				//String ss=reader.readLine();
				//System.out.println("���������յ����ݣ�"+ss);
				//System.out.println("���������յ�����2��"+msg);
				if(msg.startsWith("btn3")){
					lock=0;
					String lock_str=String.valueOf(lock);
					String s="lock"+" "+lock_str;
					socketMan.sendToAll(s);
				}
				else if(msg.startsWith("btn4")){
					lock=1;
					String lock_str=String.valueOf(lock);
					String s="lock"+" "+lock_str;
					socketMan.sendToAll(s);
				}
				else if(msg.startsWith("btn6")){
					startgame();
					//String s="btn6";
					//String lock_str=String.valueOf(lock);
					String s="btn6";
					socketMan.sendToAll(s);
				}
				else{
				String [] str=msg.split(" ");
				x=Integer.parseInt(str[0]);
				y=Integer.parseInt(str[1]);
				lock=Integer.parseInt(str[2]);
				win=Integer.parseInt(str[3]);
				play();
				String x_str=String.valueOf(x);
				String y_str=String.valueOf(y);
				String lock_str=String.valueOf(lock);
				String win_str=String.valueOf(win);
				String value_str=String.valueOf(value);
				String s=x_str+" "+y_str+" "+lock_str+" "+win_str+" "+value_str;
				System.out.println(s);
				socketMan.sendToAll(s);
			}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	}
	
public static void main(String[] args){
	server server=new server();
	server.getServer();
}
}