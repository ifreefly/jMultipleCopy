//�����������
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;
import java.io.*;
class myJpanel extends JPanel implements MouseListener,ActionListener,Runnable{
	/**
	 * version 0.1
	 */
	private static final long serialVersionUID = 1L;
	private JLabel name_label=new JLabel("�ǳ�");
	private JTextField name_text=new JTextField();
	private int[][] map=new int[20][20];
	private JButton bt1,bt2,bt3,bt4,bt5,bt6;
	private int win=0,x=-1,y=-1,lock=-1,tmp_lock=-1;
	private BufferedReader reader;//����BufferedReader�����
	private PrintWriter writer;
	private Socket socket;
	private int value;
	//private Thread thread;
	public myJpanel(){
		setLayout(null);
		bt1=new JButton("��ʼ");
		bt2=new JButton("����һ��");
		bt3=new JButton("������"); //
		bt4=new JButton("������");
		bt5=new JButton("����");
		bt6=new JButton("���¿�ʼ"); //
		bt1.setBounds(660,80,100,30);
		bt2.setBounds(660, 280, 100, 30);
		bt3.setBounds(660, 180, 100, 30);
		bt4.setBounds(660, 230, 100, 30);
		bt5.setBounds(660, 130, 100, 30);
		bt6.setBounds(660, 330, 100, 30);
		name_label.setBounds(30,630,30,30);
		name_text.setBounds(80, 630, 100, 25);
		//add(bt1);
		//add(bt2);
		add(bt3);
		add(bt4);
		add(bt5);
		add(bt6);
		add(name_label);
		add(name_text);
		bt1.addActionListener(this);
		bt2.addActionListener(this);
		bt3.addActionListener(this);
		bt4.addActionListener(this);
		bt5.addActionListener(this);
		bt6.addActionListener(this);
		addMouseListener(this);
		setBackground(Color.LIGHT_GRAY);
	}
	public void startgame(){
		for(int i=0;i<20;i++){
			for(int j=0;j<20;j++){
				map[i][j]=0;
			}
		}
	}
	   public void paintComponent(Graphics g){
		   super.paintComponent(g);
		   //������
		   
		   for(int i=0;i<=20;i++){
			   g.drawLine(30, 30*i, 600, 30*i);
			   g.drawLine(30*i,30, 30*i,600);
		   }
		   //������
		   for(int i=0;i<20;i++){
			   for(int j=0;j<20;j++){
				   if(map[i][j]==1){
					   {
						   System.out.println("���ڻ�����");
		                      g.setColor(Color.white);
		                      g.fillOval((i+1)*30-15, (j+1)*30-15, 30, 30);
		                      //System.out.println("�����");
		                 }
				   }
				   else  if(map[i][j] == 2)
		                 {
		                      System.out.println("���ڻ�����");
					   		  g.setColor(Color.black);
		                      g.fillOval((i+1)*30-15, (j+1)*30-15, 30, 30);
		                      //System.out.println("�����");
		                 }
				   }
			   }
		   Font font=new Font("",50,30);
		   if(win==1){
			   g.setFont(font);
			   g.drawString("����ʤ", 60, 100);
			   removeMouseListener(this);
		   }
		   if(win==2){
			   g.setFont(font);
			   g.drawString("����ʤ", 60, 100);
			   removeMouseListener(this);
		   }
		   }
	   
	   
	   public void actionPerformed(ActionEvent e){		   
		   if(e.getSource()==bt3){
			   lock=0;
			   tmp_lock=0;
			   startgame();
			   repaint();
			   bt3.setEnabled(false);
			   bt4.setEnabled(false);
			   writer.println("btn3"+" "+lock);
		   }
		   else if(e.getSource()==bt4){
			   lock=1;
			   tmp_lock=1;
			   startgame();
			   repaint();
			   bt3.setEnabled(false);
			   bt4.setEnabled(false);
			   writer.println("btn4"+" "+lock);
		   }
		   else if(e.getSource()==bt6){
			   System.out.println("˵�õ����¿�ʼ�أ�");
			   //startgame();
			   //repaint();
			   //win=0;
			   writer.println("btn6");
			   //bt3.setEnabled(true);
			   //bt4.setEnabled(true);
			   addMouseListener(this);
		   }
	   }
	   public void mouseClicked(MouseEvent e){
		   if(win==0&&tmp_lock==lock)
		   {			   
			   x=e.getX();
			   y=e.getY();
		   //}
		   x = (int)((x-15)/30);
	       y = (int)((y-15)/30);
	       //System.out.println("x:"+x+"y:"+y);
	       try{
	    	   System.out.println("���ڷ��͵����ݣ�"+x+" "+y+" "+tmp_lock+" "+win+" "+value);
	    	   writer.println(x+" "+y+" "+tmp_lock+" "+win);
	       }catch(Exception ex){
	    	   ex.printStackTrace();
	       }	      
	       if(tmp_lock==0)
			   tmp_lock=1;
		   else if(tmp_lock==1)
			   tmp_lock=0;
		   }
	   }
	   public void mouseEntered(MouseEvent e){}
	   public void mouseExited(MouseEvent e){}
	   public void mousePressed(MouseEvent e){
		   /*if(win==0&&tmp_lock==lock)
		   {			   
			   x=e.getX();
			   y=e.getY();
		   //}
		   x = (int)((x-15)/30);
	       y = (int)((y-15)/30);
	       //System.out.println("x:"+x+"y:"+y);
	       try{
	    	   System.out.println("���ڷ��͵����ݣ�"+x+" "+y+" "+tmp_lock+" "+win+" "+value);
	    	   writer.println(x+" "+y+" "+tmp_lock+" "+win);
	       }catch(Exception ex){
	    	   ex.printStackTrace();
	       }	      
	       if(tmp_lock==0)
			   tmp_lock=1;
		   else if(tmp_lock==1)
			   tmp_lock=0;
		   }*/
	   }
	   public void mouseReleased(MouseEvent arg0) {}
	   /*private Boolean winner(int x,int y){
		   int score=1;
		   //�ж�x++�����Ƿ��Ѿ���������
		   //System.out.println("x:"+x+"y:"+y);
		   for(int i=x;i<x+4&&i<19;){
			   //System.out.println("�ѽ����б�ʽ");
			   if(map[i][y]==map[++i][y]){
				   System.out.println(map[x][y]);
				   score++;
			   }
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�x--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int i=x;i>x-4&&i>0;){
			   if(map[i][y]==map[--i][y]){
				   score++;
				   System.out.println(score);
			   }
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�y++�����Ƿ��Ѿ���������
		   score=1;
		   for(int j=y;j<y+4&&j<19;){
			   if(map[x][j]==map[x][++j])
				   score++;
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�y--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int j=y;j>y-4&&j>0;){
			   if(map[x][j]==map[x][--j])
				   score++;
			   else
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�x++&&y++�����Ƿ��Ѿ���������
		   score=1;
		   for(int i=x,j=y;i<x+4&&i<19&&j>0;){
			   if(map[i][j]==map[++i][--j])
				   score++;
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		 //�ж�x--&&y--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int i=x,j=y;i>x-4&&i>0&&j<19;){
			   //System.out.println("x++&&y++�����б�ing...");
			   if(map[i][j]==map[--i][++j])
				   score++;
			   else
				   break;
			   System.out.println("x++&&y++�����б�ing..."+score);
			   if(score>=5)
				   return true;
		   }
		 //�ж�x--&&y++�����Ƿ��Ѿ���������
		   score=1;
		   for(int i=x,j=y;i>x-4&&i>0&&j>0;){
			   if(map[i][j]==map[--i][--j])
				   score++;
			   else
				   break;
			   //System.out.println(score);
			   if(score>=5)
				   return true;
		   }
		 
		   //�ж�x++&&y--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int i=x,j=y;i<x+4&&i<19&&j<19;){
			   if(map[i][j]==map[++i][++j])
				   score++;
			   else
				   break;
			   System.out.println(score);
			   if(score>=5)
				   return true;
		   }
		   return false;
		   }*/
	   public void run(){
		   while(true){
			   try{				   
			       String ss;
			       if((ss=reader.readLine())!=null){//������̵��ʼ�ĳ�ʼ��,���ִ�����⣡
			    	   if(ss.startsWith("lock")){
			    		   String[] tmp_str=ss.split(" ");
			    		   if(Integer.parseInt(tmp_str[1])==1){
			    			   if(lock==1)
			    				   ;
			    			   else{
			    				   lock=0;
			    				   //tmp_lock=0;
			    				   startgame();
			    				   bt3.setEnabled(false);
			    				   bt4.setEnabled(false);
			    			   }
			    		   }
			    		   else{
			    			   if(lock==0)
			    				   ;
			    			   else{
			    				   lock=1;
			    				   //tmp_lock=1;
			    				   startgame();
			    				   bt3.setEnabled(false);
			    				   bt4.setEnabled(false);
			    			   }
			    		   }   
			    	   }
			    	   else if(ss.equals("btn6")){
			    		   System.out.println("�������¿�ʼ....");
			    		   startgame();
						   repaint();
						   win=0;
						   //bt3.setEnabled(true);
						   //bt4.setEnabled(true);
			    	   }
			    	   else{
			    		   String [] str=ss.split(" ");
			    		   x=Integer.parseInt(str[0]);
			    		   y=Integer.parseInt(str[1]);
			    		   tmp_lock=Integer.parseInt(str[2]);
			    		   win=Integer.parseInt(str[3]);
			    		   value=Integer.parseInt(str[4]);
			    		   if(x>=0&&x<=19&&y>=0&&y<=19&&map[x][y]==0)
			    			   map[x][y]=value;
				   //System.out.println("���ڽ��ܵ����ݣ�"+x+" "+y+" "+tmp_lock+" "+win+" "+value);
				   repaint();
			       }		
			       }
			   }catch(Exception e){
				   e.printStackTrace();
			   }
		   }
	   }
	   public void getSocket(){
		   System.out.println("���ڳ��������������");
		   try{
			   socket=new Socket("127.0.0.1",5421);
			   System.out.println("����׼�����");
			   reader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
			   writer=new PrintWriter(socket.getOutputStream(),true);
			   new Thread(this).start();
		   }catch(Exception e){
			   e.printStackTrace();
		   }
	   } 
}
class myFrame extends JFrame{
	public  myJpanel myjpanel=new myJpanel();
	public myFrame(){
		super("������");
		add(myjpanel);
		setSize(800,800);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
public class ServerClient {
	public static void main(String[] args){
		myFrame myframe=new myFrame();
		myframe.myjpanel.getSocket();
	}
}
