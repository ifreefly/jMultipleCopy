import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
class myJpanel extends JPanel implements MouseListener,ActionListener{
	private int[][] map=new int[20][20];
	private JButton bt1,bt2,bt3,bt4,bt5,bt6;
	private int flag=0,win=0,x=-1,y=-1;
	private Vector maps=new Vector();//maps�����洢map�������Ա���л��壡
	public myJpanel(){
		setLayout(null);
		bt1=new JButton("��ʼ");
		bt2=new JButton("����һ��");
		bt3=new JButton("������"); //
		bt4=new JButton("������");
		bt5=new JButton("����");
		bt6=new JButton("���¿�ʼ"); //
		bt1.setBounds(660,80,100,30);
		bt2.setBounds(660, 280, 100, 30);
		bt3.setBounds(660, 180, 100, 30);
		bt4.setBounds(660, 230, 100, 30);
		bt5.setBounds(660, 130, 100, 30);
		bt6.setBounds(660, 330, 100, 30);
		//add(bt1);
		//add(bt2);
		add(bt3);
		add(bt4);
		add(bt5);
		add(bt6);
		bt1.addActionListener(this);
		bt2.addActionListener(this);
		bt3.addActionListener(this);
		bt4.addActionListener(this);
		bt5.addActionListener(this);
		bt6.addActionListener(this);
		addMouseListener(this);
		setBackground(Color.LIGHT_GRAY);
	}
	/*public int getFlag(){
		return flag;
	}
	public int setFlag(int flag){
		this.flag=flag;
		return flag;
	}*/
	public void start(){
		for(int i=0;i<20;i++){
			for(int j=0;j<20;j++){
				map[i][j]=0;
			}
		}
	}
	   public void paintComponent(Graphics g){
		   super.paintComponent(g);
		   //������
		   for(int i=0;i<=20;i++){
			   g.drawLine(30, 30*i, 600, 30*i);
			   g.drawLine(30*i,30, 30*i,600);
		   }
		   //������
		   for(int i=0;i<20;i++){
			   for(int j=0;j<20;j++){
				   if(map[i][j]==1){
					   {
		                      g.setColor(Color.white);
		                      g.fillOval((i+1)*30-15, (j+1)*30-15, 30, 30);
		                      //System.out.println("�����");
		                 }
				   }
				   else  if(map[i][j] == 2)
		                 {
		                      g.setColor(Color.black);
		                      g.fillOval((i+1)*30-15, (j+1)*30-15, 30, 30);
		                      //System.out.println("�����");
		                 }
				   }
			   }
		   Font font=new Font("",50,30);
		   if(win==1){
			   g.setFont(font);
			   g.drawString("����ʤ", 60, 100);
			   removeMouseListener(this);
		   }
		   if(win==2){
			   g.setFont(font);
			   g.drawString("����ʤ", 60, 100);
			   removeMouseListener(this);
		   }
		   }
	   
	   
	   public void actionPerformed(ActionEvent e){
		   if(e.getSource()==bt3){
			   flag=1;
			   start();
			   repaint();
			   bt3.setEnabled(false);
			   bt4.setEnabled(false);
		   }
		   else if(e.getSource()==bt4){
			   flag=2;
			   start();
			   repaint();
			   bt3.setEnabled(false);
			   bt4.setEnabled(false);
		   }
		   else if(e.getSource()==bt5){
			   int size=maps.size()-1;
			   for(int i=0;i<size;i++){
				   
			   }
		   }
		   else if(e.getSource()==bt6){
			   System.out.println("˵�õ����¿�ʼ�أ�");
			   start();
			   repaint();
			   win=0;
			   //bt3.setEnabled(true);
			   //bt4.setEnabled(true);
			   addMouseListener(this);
		   }
	   }
	   public void mouseClicked(MouseEvent e){
		   if(win==0)
		   {
			   x=e.getX();
			   y=e.getY();
			   System.out.println("x:"+x+"y:"+y);
		   }
		   //if(x>15&&x<615&&y>15&&y<615)
		   //{
			   x = (int)((x-15)/30);
			   y = (int)((y-15)/30);
		  // }
	       if(x>=0&&x<=19&&y>=0&&y<=19&&map[x][y]==0){
	    	   if(flag==1){
	    		   map[x][y]=1;
	    		   //System.out.println("x:"+x+"y:"+y);
	    		   flag=2;
	    		   maps.add(map[x][y]);
	    		   if(winner(x,y)){
	    			   win=1;
	    		       bt2.setEnabled(true);
    			       //bt3.setEnabled(true);
    			       //bt4.setEnabled(true);
    			       bt5.setEnabled(false);
    			   }
	    		   //System.out.println("�������ߡ�"+flag);
	    	   }
	    	   else if(flag==2){
	    		   map[x][y]=2;
	    		   flag=1;
	    		   maps.add(map[x][y]);
	    		   if(winner(x,y)){
	    			   win=2;
	    			   bt2.setEnabled(true);
	    			   //bt3.setEnabled(true);
	    			   //bt4.setEnabled(true);
	    			   bt5.setEnabled(false);
	    		   }
	    	   }
	       }
	       repaint();
	   }
	   public void mouseEntered(MouseEvent e){}
	   public void mouseExited(MouseEvent e){}
	   public void mousePressed(MouseEvent e){
		   /*if(win==0)
		   {
			   x=e.getX();
			   y=e.getY();
		   }
		   x = (int)((x-15)/30);
	       y = (int)((y-15)/30);
	       System.out.println("x:"+x+"y:"+y);
	       if(x>=0&&x<=19&&y>=0&&y<=19&&map[x][y]==0){
	    	   if(flag==1){
	    		   map[x][y]=1;
	    		   //System.out.println("x:"+x+"y:"+y);
	    		   flag=2;
	    		   if(winner(x,y)){
	    			   win=1;
	    		       bt2.setEnabled(true);
    			       //bt3.setEnabled(true);
    			       //bt4.setEnabled(true);
    			       bt5.setEnabled(false);
    			   }
	    		   //System.out.println("�������ߡ�"+flag);
	    	   }
	    	   else if(flag==2){
	    		   map[x][y]=2;
	    		   flag=1;
	    		   if(winner(x,y)){
	    			   win=2;
	    			   bt2.setEnabled(true);
	    			   //bt3.setEnabled(true);
	    			   //bt4.setEnabled(true);
	    			   bt5.setEnabled(false);
	    		   }
	    	   }
	       }
	       repaint();*/
	   }
	   public void mouseReleased(MouseEvent arg0) {}
	   public Boolean winner(int x,int y){
		   int score=1;
		   //�ж�x++�����Ƿ��Ѿ���������
		   //System.out.println("x:"+x+"y:"+y);
		   for(int i=x;i<x+4&&i<19;){
			   //System.out.println("�ѽ����б�ʽ");
			   if(map[i][y]==map[++i][y]){
				   System.out.println(map[x][y]);
				   score++;
			   }
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�x--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int i=x;i>x-4&&i>0;){
			   if(map[i][y]==map[--i][y]){
				   score++;
				   System.out.println(score);
			   }
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�y++�����Ƿ��Ѿ���������
		   score=1;
		   for(int j=y;j<y+4&&j<19;){
			   if(map[x][j]==map[x][++j])
				   score++;
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�y--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int j=y;j>y-4&&j>0;){
			   if(map[x][j]==map[x][--j])
				   score++;
			   else
				   break;
		   }
		   if(score>=5)
			   return true;
		   //�ж�x++&&y++�����Ƿ��Ѿ���������
		   score=1;
		   for(int i=x,j=y;i<x+4&&i<19&&j>0;){
			   if(map[i][j]==map[++i][--j])
				   score++;
			   else 
				   break;
		   }
		   if(score>=5)
			   return true;
		 //�ж�x--&&y--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int i=x,j=y;i>x-4&&i>0&&j<19;){
			   //System.out.println("x++&&y++�����б�ing...");
			   if(map[i][j]==map[--i][++j])
				   score++;
			   else
				   break;
			   System.out.println("x++&&y++�����б�ing..."+score);
			   if(score>=5)
				   return true;
		   }
		 //�ж�x--&&y++�����Ƿ��Ѿ���������
		   score=1;
		   for(int i=x,j=y;i>x-4&&i>0&&j>0;){
			   if(map[i][j]==map[--i][--j])
				   score++;
			   else
				   break;
			   //System.out.println(score);
			   if(score>=5)
				   return true;
		   }
		 
		   //�ж�x++&&y--�����Ƿ��Ѿ���������
		   //score=1;
		   for(int i=x,j=y;i<x+4&&i<19&&j<19;){
			   if(map[i][j]==map[++i][++j])
				   score++;
			   else
				   break;
			   System.out.println(score);
			   if(score>=5)
				   return true;
		   }
		   return false;
		   }
}
class myFrame extends JFrame{
	private myJpanel myjpanel=new myJpanel();
	public myFrame(){
		super("������");
		add(myjpanel);
		setSize(800,800);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
public class client {
	public static void main(String[] args){
		myFrame myframe=new myFrame();
	}
}